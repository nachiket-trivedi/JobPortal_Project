set search_path to job_portal;


insert into Users(user_ID, mobile_no, email, url, address) 
values('0001',07046525093,'betty.sanders@gmail.com','www.bettysanders.me','6 Cypress Gardens, Sutton Coldfield B74 2HD, UK');
insert into Users(user_ID, mobile_no, email, url, address) 
values('0002',4028980901,'randy.martin@gmail.com','www.randymartin.me','8681 Inverness Ave. South Bend, IN 46614');
insert into Users(user_ID, mobile_no, email, url, address) 
values('0003',7057480618,'jacklei12@gmail.com','www.jackolei.me','232 George StreetPeterborough, ON K9H 2L1');
insert into Users(user_ID, mobile_no, email, url, address) 
values('0004',0152418393,'zurie234@yahoo.com','www.iamzurie.me','43, Quai des Belges59600 MAUBEUGE');
insert into Users(user_ID, mobile_no, email, url, address) 
values('0005',9658742314,'patelmayur14@gmail.com','www.mayur_patel.me','18C, Ganga Flats, Borivali East, Mumbai');
insert into Users(user_ID, mobile_no, email, url, address) 
values('0006',21253776325,'NormanETrahan@teleworm.us','www.normanTrahan56.me','R Bacelo 384800-252 RENDUFE, Portugal');
insert into Users(user_ID, mobile_no, email, url, address) 
values('0007',26034357296,'PaulineMMoreira@dayrep.com','www.pauline153.me','2353 Grasselli Street Pittsfield, NH 03263, USA');
insert into Users(user_ID, mobile_no, email, url, address) 
values('0008',01145617896,'ishitathakker34@gmail.com','www.thakkerIshita.me','15D-Krishna Appartment, Andheri West, Mumbai');
insert into Users(user_ID, mobile_no, email, url, address) 
values('0009',07065871285,'alexander534@gmail.com','www.alexsmith.me','47 Fordham Rd HALLOW HEATHWR 2 8WU, London, UK');
insert into Users(user_ID, mobile_no, email, url, address) 
values('0010',01145617896,'matsudayag423@gmail.com','www.matsudayagami9.me','150-2345 shikoru, Shibuya-ku, Tokyo');


insert into Users(user_ID, mobile_no, email, url, address) 
values('1001',0577551073,'askunitaxon@gmail.com','www.unitaxon.com','97 Hunter StreetNORTH TOOWOOMBA QLD 4350,Australia');
insert into Users(user_ID, mobile_no, email, url, address) 
values('1002',04141898965,'mailitfinfix@hotmail.com','www.itfinfix.org','Inge Beisheim Platz 3421720 Gr�nendeich,Germany');
insert into Users(user_ID, mobile_no, email, url, address) 
values('1003',3876778579,'mail@conefax.io','conefax.io','Rua Argos, 1752 Montes Claros-MG39401-231,Brazil');
insert into Users(user_ID, mobile_no, email, url, address) 
values('1004',45565608904,'mail@keystriker.com','www.keystriker.com','200 Peel View Place Waimataitai Timaru 7910,New Zealand');
insert into Users(user_ID, mobile_no, email, url, address) 
values('1005',01136521478,'mail@lexitech.io','lexitech.io','36-shamsundar complex, Connaught place, New Delhi');
insert into Users(user_ID, mobile_no, email, url, address) 
values('1006',07818964653,'askdarbyhospitals@gmail.com','www.darbyhospitals.com','126, Darlington Street, Paris, France');
insert into Users(user_ID, mobile_no, email, url, address) 
values('1007',1563223056,'mail@spaceq.org','www.spaceq.org','465b, Berkshire Abbey, London, UK');
insert into Users(user_ID, mobile_no, email, url, address) 
values('1008',771575651,'mail@stratonoak.com','www,stratonoak.com','186-2nd block, 55 Wall Street, New York City');
insert into Users(user_ID, mobile_no, email, url, address) 
values('1009',1833456465,'mail@shinagami.com','www.shinagami.com','56-misa amane, hikoshu street, Tokyo, Japan');
insert into Users(user_ID, mobile_no, email, url, address) 
values('1010',56958966,'mail@pearsonspecterlitt.com','www.pearsonspecterlitt','81st street, 5th avenue, downtown Manhattan, New York City');



insert into Applicant(user_ID, fname, minit, lname, gender, dob, grad_year, tenth_per, twelfth_per, degree_ql, nationality, university, marital_status) 
values('0001','Betty','J','Sanders','F', DATE '1970-11-5','1995', '91', '93', 'Bachelor in Commerce', 'British', 'Oxford University', 'Unmarried');
insert into Applicant(user_ID, fname, minit, lname, gender, dob, grad_year, tenth_per, twelfth_per, degree_ql, nationality, university, marital_status) 
values('0002','Randy','O','Martin','F', DATE '1980-12-15','2003', '80', '85', 'Master in Mechanical Engg.', 'American', 'University of Pennsylvania', 'Married');
insert into Applicant(user_ID, fname, minit, lname, gender, dob, grad_year, tenth_per, twelfth_per, degree_ql, nationality, university, marital_status) 
values('0003','Jack','O','Lei','M', DATE '1988-02-12','2005', '92', '95', 'Bachelor in CSE', 'Canadian', 'University of Toronto', 'Unmarried');
insert into Applicant(user_ID, fname, minit, lname, gender, dob, grad_year, tenth_per, twelfth_per, degree_ql, nationality, university, marital_status) 
values('0004','Zurie','N','Dagenais','F', DATE '1998-05-02','2019', '72', '75', 'Bachelor in Arts', 'French', 'University of Paris', 'Unmarried');
insert into Applicant(user_ID, fname, minit, lname, gender, dob, grad_year, tenth_per, twelfth_per, degree_ql, nationality, university, marital_status) 
values('0005','Mayur','D','Patel','M', DATE '1990-12-11', '2005','90', '91', 'Master in CSE', 'Indian', 'Narsee Monjee', 'Unmarried');
insert into Applicant(user_ID, fname, minit, lname, gender, dob, grad_year, tenth_per, twelfth_per, degree_ql, nationality, university, marital_status) 
values('0006','Norman','E','Trahan','M', DATE '1994-03-21','2015', '80', '82', 'MBA', 'Portuguese', 'Lisbon University', 'Unmarried');
insert into Applicant(user_ID, fname, minit, lname, gender, dob, grad_year, tenth_per, twelfth_per, degree_ql, nationality, university, marital_status) 
values('0007','Pauline','M','Moriera','F', DATE '1997-06-01','2020', '90', '93', 'Bachelor in Architechture', 'American', 'Stanford University', 'Unmarried');
insert into Applicant(user_ID, fname, minit, lname, gender, dob, grad_year, tenth_per, twelfth_per, degree_ql, nationality, university, marital_status) 
values('0008','Ishita','P','Thakker','F', DATE '1996-01-05', '2018','94', '95', 'MBBS', 'Indian', 'Grant Medical College', 'Unmarried');
insert into Applicant(user_ID, fname, minit, lname, gender, dob, grad_year, tenth_per, twelfth_per, degree_ql, nationality, university, marital_status) 
values('0009','Alexander','V','Smith','M', DATE '1989-04-15','2005', '84', '89', 'Master in IT Engineering', 'British', 'Cambridge University', 'Married');
insert into Applicant(user_ID, fname, minit, lname, gender, dob, grad_year, tenth_per, twelfth_per, degree_ql, nationality, university, marital_status) 
values('0010','Matsuda','K','Yagami','M', DATE '1980-10-10','2003', '88', '85', 'Master in Aerospace Engg.', 'Japanese', 'Tokyo University', 'Married');




insert into Company(user_ID, company_name, description)
values('1001','Unitaxon Pvt. Ltd.','Car Manufacturers');
insert into Company(user_ID, company_name, description)
values('1002','Itfinfix Inc.','Oil Company');
insert into Company(user_ID, company_name, description)
values('1003','conefax.io','Tech company');
insert into Company(user_ID, company_name, description)
values('1004','Keystriker Inc.','Car Manufacturers');
insert into Company(user_ID, company_name, description)
values('1005','lexitech.io','Tech company');
insert into Company(user_ID, company_name, description)
values('1006','Darby Hospitals','Hopital Franchises');
insert into Company(user_ID, company_name, description)
values('1007','SpaceQ','Aerospace manufacturer');
insert into Company(user_ID, company_name, description)
values('1008','Straton Oak','Investment banking and stock brokers');
insert into Company(user_ID, company_name, description)
values('1009','Shinigami Inc.','Electrical Company');
insert into Company(user_ID, company_name, description)
values('1010','Pearson Specter Litt','Law Firm');

/**/
