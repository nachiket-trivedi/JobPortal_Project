CREATE SCHEMA job_portal;
SET SEARCH_PATH TO job_portal;

CREATE TABLE Users
(
user_ID INTEGER,
mobile_no BIGINT,
email VARCHAR(30),
url VARCHAR(30),
address VARCHAR(100),
PRIMARY KEY(user_ID)
);

CREATE TABLE Applicant 
(
user_ID INTEGER,
fname VARCHAR(20) NOT NULL,
minit CHAR(1),
lname VARCHAR(20),
gender CHAR(1) NOT NULL,
dob DATE,
grad_year INTEGER,
tenth_per INTEGER,
twelfth_per INTEGER,
degree_ql VARCHAR(30),
nationality VARCHAR(30),
university VARCHAR(30),
marital_status VARCHAR(10),
PRIMARY KEY(user_ID)
);


CREATE TABLE Company
(
user_ID INTEGER,
company_name VARCHAR(40) NOT NULL,
description VARCHAR(100),
PRIMARY KEY(user_ID)
);

CREATE TABLE Projects
(
applicant_ID INTEGER,
p_name VARCHAR(20) NOT NULL,
p_type VARCHAR(20) NOT NULL,
description VARCHAR(100),
mentor VARCHAR(20),
start_date DATE NOT NULL,
end_date DATE NOT NULL,
FOREIGN KEY(applicant_ID) REFERENCES Applicant(user_ID) ON DELETE CASCADE ON UPDATE CASCADE,
PRIMARY KEY(applicant_ID,p_name)
);

CREATE TABLE Job
(
job_ID INTEGER,
company_ID INTEGER NOT NULL,
department VARCHAR(30) NOT NULL,
vacancies INTEGER NOT NULL,
job_type VARCHAR(30) NOT NULL,
designation VARCHAR(30) NOT NULL,
desired_work_experience VARCHAR(30),
sector VARCHAR(30),
location VARCHAR(30),
work_hours INTEGER NOT NULL,
salary INTEGER NOT NULL,
desired_ql VARCHAR(30),
description VARCHAR(30),
apply_before DATE NOT NULL,
PRIMARY KEY(job_ID),	
FOREIGN KEY(company_ID) REFERENCES Company(user_ID) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE Skills
(
skill_name VARCHAR(30),
PRIMARY KEY(skill_name)
);

CREATE TABLE Applicant_skills
(
applicant_ID INTEGER,
skill VARCHAR(30),
FOREIGN KEY(applicant_ID) REFERENCES Applicant(user_ID) ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(skill) REFERENCES Skills(skill_name) ON DELETE CASCADE ON UPDATE CASCADE,
PRIMARY KEY(applicant_ID,skill)
);

CREATE TABLE Work_experience
(
applicant_ID INTEGER,
prev_company VARCHAR(30),
prev_jobtype VARCHAR(30),
prev_designation VARCHAR(30),
prev_sector VARCHAR(30),
prev_salary INTEGER,
start_date DATE NOT NULL,
end_date DATE NOT NULL,
FOREIGN KEY(applicant_ID) REFERENCES APPLICANT(user_ID) ON DELETE CASCADE ON UPDATE CASCADE,
PRIMARY KEY(applicant_ID, start_date, end_date)
);

CREATE TABLE Skills_required
(
job_ID INTEGER,
skill VARCHAR(100),
FOREIGN KEY(skill) REFERENCES Skills(skill_name) ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(job_ID) REFERENCES Job(job_ID) ON DELETE CASCADE ON UPDATE CASCADE,
PRIMARY KEY(job_ID,skill)
);

CREATE TABLE Application_status
(
job_ID INTEGER,
applicant_ID INTEGER,
status VARCHAR(3) NOT NULL,
time_stamp TIMESTAMP,
FOREIGN KEY(applicant_ID) REFERENCES Applicant(user_ID) ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(job_ID) REFERENCES Job(job_ID) ON DELETE CASCADE ON UPDATE CASCADE,
PRIMARY KEY(applicant_ID, job_ID)
);

CREATE TABLE Interview
(
job_ID INTEGER,
applicant_ID INTEGER,
scheduled_date DATE NOT NULL,
scheduled_time TIME NOT NULL,
result VARCHAR(15) NOT NULL,
FOREIGN KEY(applicant_ID) REFERENCES Applicant(user_ID) ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(job_ID) REFERENCES Job(job_ID) ON DELETE CASCADE ON UPDATE CASCADE,
PRIMARY KEY(applicant_ID, job_ID)
);

CREATE TABLE Advertising_cost
(
advertising_type VARCHAR(30),
cost_per_30_days INTEGER,
PRIMARY KEY(advertising_type)
);

CREATE TABLE Advertisement
(
job_ID INTEGER,
month INTEGER,
year INTEGER,
days_of_advertisement INTEGER,
advertisement_type VARCHAR(30),
FOREIGN KEY(advertisement_type) REFERENCES Advertising_cost(advertising_type) ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY(job_ID) REFERENCES Job(job_ID) ON DELETE CASCADE ON UPDATE CASCADE,
PRIMARY KEY(job_ID, month, year)
);



